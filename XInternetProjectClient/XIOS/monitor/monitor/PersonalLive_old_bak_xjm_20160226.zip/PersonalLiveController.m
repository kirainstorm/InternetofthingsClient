//
//  SecondViewController.m
//  monitor
//
//  Created by xjm on 16/1/18.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import "PersonalLiveController.h"
#import "PersonalLiveControllerCell.h"
#import "PersonalLiveControllerCellHeader.h"


@interface PersonalLiveController ()

@end

static CGFloat ImageHeight = 180;

@implementation PersonalLiveController

@synthesize colView;
static NSString *cellIdentifier = @"PersonalLiveCell";
static NSString *headerIdentifier = @"PersonalLiveCellHeader";
static CGFloat cellSpace = 1;



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.arrayImages = [NSArray arrayWithObjects:[UIImage imageNamed:@"monkey"],[UIImage imageNamed:@"mouse"],[UIImage imageNamed:@"third.jpg"],[UIImage imageNamed:@"testt4.png"], nil];
    
    //_scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,ImageHeight)];
    [_scrollView setPagingEnabled:YES];
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    [_scrollView setDelegate:self];
    //[_scrollView setBackgroundColor:[UIColor lightGrayColor]];

    //ContentSize 这个属性对于UIScrollView挺关键的，取决于是否滚动。
    [_scrollView setContentSize:CGSizeMake(CGRectGetWidth(self.view.frame) * [self.arrayImages count], ImageHeight)];
    [self.view addSubview:_scrollView];
    
    _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, self.scrollView.frame.size.height - 20, [UIScreen mainScreen].bounds.size.width, 20)];
    [_pageControl setBackgroundColor:[UIColor cyanColor]];
    
   // [_pageControl setFrame:CGRectMake(0, self.scrollView.frame.size.height , self.scrollView.frame.size.width, 20)];
    
    
    _pageControl.currentPage = 0;
    _pageControl.numberOfPages = [self.arrayImages count];
    [_pageControl addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:_pageControl];

    _viewController = [[NSMutableArray alloc] init];
    
    for (NSInteger i = 0; i < [self.arrayImages count]; i++) {
        [_viewController addObject:[NSNull null]];
    }
    
    [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(scrollPages) userInfo:nil repeats:YES];
    
    [self loadScrollViewPage:0];
    [self loadScrollViewPage:1];
    [self loadScrollViewPage:2];
    [self loadScrollViewPage:3];
    
    
    ///
    self.colView.delegate = self;
    self.colView.dataSource = self;
    
    [self.colView registerClass:[PersonalLiveControllerCell class] forCellWithReuseIdentifier:cellIdentifier];
    [self.colView registerClass:[PersonalLiveControllerCellHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerIdentifier];
    
    
    //[collectionView registerClass:[FootView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:footerIdentifier];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)loadScrollViewPage:(NSInteger)page
{
    if (page >= self.arrayImages.count) {
        return;
    }
    
    UIViewController *imageViewController = [self.viewController objectAtIndex:page];
    if ((NSNull *)imageViewController == [NSNull null])
    {
        imageViewController = [[UIViewController alloc] init];
        [self.viewController replaceObjectAtIndex:page withObject:imageViewController];
    }
    
    if (imageViewController.view.superview == nil) {
        CGRect frame = self.scrollView.frame;
        frame.origin.x = CGRectGetWidth(frame) * page;
        frame.origin.y = 0;
        imageViewController.view.frame = frame;
        
        //[self addChildViewController:imageViewController];
        [self.scrollView addSubview:imageViewController.view];
        [imageViewController didMoveToParentViewController:self];
        
        [imageViewController.view setBackgroundColor:[UIColor colorWithPatternImage:(UIImage *)[self.arrayImages objectAtIndex:page]]];
    }
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth = CGRectGetWidth(self.scrollView.frame);
    NSInteger page = floor((self.scrollView.contentOffset.x -pageWidth/2)/pageWidth) +1;
    self.pageControl.currentPage = page;
    
    [self loadScrollViewPage:page-1];
    [self loadScrollViewPage:page];
    [self loadScrollViewPage:page+1];
}
- (IBAction)changePage:(id)sender
{
    NSInteger page = self.pageControl.currentPage;
    
    [self loadScrollViewPage:page - 1];
    [self loadScrollViewPage:page];
    [self loadScrollViewPage:page + 1];
    
    CGRect bounds = self.scrollView.bounds;
    bounds.origin.x = CGRectGetWidth(bounds) * page;
    bounds.origin.y = 0;
    [self.scrollView scrollRectToVisible:bounds animated:YES];
}
-(void)scrollPages{
    ++self.pageControl.currentPage;
    CGFloat pageWidth = CGRectGetWidth(self.scrollView.frame);
    if (isFromStart) {
        [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        self.pageControl.currentPage = 0;
    }
    else
    {
        [self.scrollView setContentOffset:CGPointMake(pageWidth*self.pageControl.currentPage, self.scrollView.bounds.origin.y)];
        
    }
    if (_pageControl.currentPage == _pageControl.numberOfPages - 1) {
        isFromStart = YES;
    }
    else
    {
        isFromStart = NO;
    }
}
//----------------------------------------------------------------------------------

#pragma mark - UICollectionViewDataSource
//每一组有多少个cell
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"numberOfItemsInSection section=%ld",(long)section);
//    if (section == 0) {
//        return 4;
//    }
//    if (section == 1) {
//        return 2;
//    }
//    if (section == 2) {
//        return 1;
//    }
    return 8;//返回每组的cell的总数，因为使用流式布局，每一行可以通过cell大小自动计算显示几个item
}
//collectionView里有多少个组
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;//这里一直返回3，只有3个组
}
//定义并返回每个cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
       
    }
    if (indexPath.section == 1) {
        
    }
    if (indexPath.section == 2) {
        
    }
    
    PersonalLiveControllerCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    [cell sizeToFit];
    if (!cell) {
        NSLog(@"wu fa chuangjian cell deviceviewcontroller");
    }
    cell.imgView.image = [UIImage imageNamed:@"cat.png"];
    cell.text.text = [NSString stringWithFormat:@"cell %ld",(long)indexPath.row];
    return cell;
}
//定义并返回每个headerView或footerView
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    CGRect rx =  [[UIScreen mainScreen] bounds];
    CGFloat w = rx.size.width;
    CGFloat h = 0;//30;///-------------------表头的高度
    
    return CGSizeMake(w, h);
}
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    //------------------------------------------------------------------
    if (indexPath.section == 0) {
        if (kind == UICollectionElementKindSectionHeader) {
            PersonalLiveControllerCellHeader *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:headerIdentifier forIndexPath:indexPath];
            headerView.text.text = @"  让我组成头部!111";
            //headerView.text.textAlignment = NSTextAlignmentLeft;
            //headerView.text.textColor = [UIColor whiteColor];
            
            return headerView;
        }
        if (kind == UICollectionElementKindSectionFooter) {
            
        }
    }
    if (indexPath.section == 1) {
        if (kind == UICollectionElementKindSectionHeader) {
            PersonalLiveControllerCellHeader *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:headerIdentifier forIndexPath:indexPath];
            headerView.text.text = @"  让我组成头部!222";
            //headerView.text.textAlignment = NSTextAlignmentLeft;
            //headerView.text.textColor = [UIColor whiteColor];
            return headerView;
        }
        if (kind == UICollectionElementKindSectionFooter) {
            
        }
    }
    if (indexPath.section == 2) {
        if (kind == UICollectionElementKindSectionHeader) {
            PersonalLiveControllerCellHeader *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:headerIdentifier forIndexPath:indexPath];
            headerView.text.text = @"  让我组成头部!333";
            //headerView.text.textAlignment = NSTextAlignmentLeft;
            //headerView.text.textColor = [UIColor whiteColor];
            return headerView;
        }
        if (kind == UICollectionElementKindSectionFooter) {
            
        }
    }
    //------------------------------------------------------------------
    
    
    return nil;
    //    UICollectionReusableView *headview = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReusableView" forIndexPath:indexPath];
    //
    //    [headview addSubview: ]
    //    return headview;
}
#pragma mark - UICollectionViewDelegate
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    NSLog(@"device colletion view : %ld %ld ",(long)indexPath.section,(long)indexPath.row);
    
    
//    dispatch_async(dispatch_get_main_queue(), ^{
//        PlayViewController * playview = ([[PlayViewController alloc] initWithNibName:@"PlayViewController" bundle:nil]);
//        [self presentViewController:playview animated:YES completion:nil];
//    });
}
//can be select
-(BOOL) collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    
    return YES;
}
#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    CGRect rx =  [[UIScreen mainScreen] bounds];
    CGFloat w = rx.size.width/2 - cellSpace - cellSpace/2 ;//8==cellSpace
    CGFloat h = w*9/16 + 16;
    
    return CGSizeMake(w, h);
}
-(UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(cellSpace, cellSpace, cellSpace, cellSpace);
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return cellSpace;
}
//cell的最小行间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return cellSpace;
}

@end
