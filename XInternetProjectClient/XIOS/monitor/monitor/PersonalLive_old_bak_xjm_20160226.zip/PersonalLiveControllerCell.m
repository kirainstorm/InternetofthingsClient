//
//  LiveViewControllerCell.m
//  monitor
//
//  Created by xjm on 16/1/20.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import "PersonalLiveControllerCell.h"

@implementation PersonalLiveControllerCell

static CGFloat LIVE_VIEW_CELL_LABEL_HEIGHT = 16;


-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        //
        self.backgroundColor = [UIColor purpleColor];
        //
//        self.imgView = [[UIImageView alloc]initWithFrame:CGRectMake(1, 1, CGRectGetWidth(self.frame) - 2, CGRectGetHeight(self.frame)- LIVE_VIEW_CELL_LABEL_HEIGHT - 2)];
//        self.imgView.backgroundColor = [UIColor groupTableViewBackgroundColor];
//        [self addSubview:self.imgView];
//        //
//        self.text = [[UILabel alloc]initWithFrame:CGRectMake(1, CGRectGetMaxY(self.imgView.frame), CGRectGetWidth(self.frame) - 2, LIVE_VIEW_CELL_LABEL_HEIGHT)];
//        self.text.backgroundColor = [UIColor brownColor];
//        self.text.textAlignment = NSTextAlignmentCenter;
//        [self addSubview:self.text];
//        //
//        //self.textEx = [[UILabel alloc]initWithFrame:CGRectMake(1, CGRectGetMaxY(self.text.frame), CGRectGetWidth(self.frame) - 2, 10)];
//        //self.textEx.backgroundColor = [UIColor brownColor];
//        //self.textEx.textAlignment = NSTextAlignmentCenter;
//        //[self addSubview:self.textEx];
//        
//        [self.text setFont:[UIFont systemFontOfSize:10]];
        
        //self.contentView.backgroundColor = [UIColor grayColor];
        
        self.imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        self.imgView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        [self addSubview:self.imgView];
        
        
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected
{
    [super setSelected:selected];
//    
//    if (selected) {
//        //        [UIView animateWithDuration:1.0 delay:0 options:UIViewAnimationOptionAllowUserInteraction animations:^{
//        //            self.contentView.backgroundColor = [UIColor redColor];
//        //        } completion:^(BOOL finished) {
//        //            self.contentView.backgroundColor = [UIColor greenColor];
//        //        }];
//        self.contentView.backgroundColor = [UIColor redColor];
//    }
//    else
//    {
//        self.contentView.backgroundColor = [UIColor grayColor];
//    }
    
    
}
@end
