//
//  LiveViewControllerCellHeader.m
//  monitor
//
//  Created by xjm on 16/1/20.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import "PersonalLiveControllerCellHeader.h"

@implementation PersonalLiveControllerCellHeader
static CGFloat LIVE_BUTTON_WIDTH = 64;

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //
        self.backgroundColor = [UIColor purpleColor];
        
//#
//               //
//        self.text = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame) - LIVE_BUTTON_WIDTH, CGRectGetHeight(self.frame))];
//        self.text.backgroundColor = [UIColor brownColor];
//        self.text.textAlignment = NSTextAlignmentLeft;
//        [self.text setFont:[UIFont systemFontOfSize:14]];
//        [self addSubview:self.text];
//        //
//        self.button =[UIButton buttonWithType:UIButtonTypeCustom];
//        self.button.frame = CGRectMake( CGRectGetWidth(self.frame) - LIVE_BUTTON_WIDTH,0, LIVE_BUTTON_WIDTH, CGRectGetHeight(self.frame));
//        [self.button setTitle:@"More..." forState:UIControlStateNormal];
//        self.button.backgroundColor = [UIColor orangeColor];
//        [self.button setValue:[UIFont systemFontOfSize:12] forKey:@"font"];
//        [self addSubview:self.button]; 
//#

        //
        self.text = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        self.text.backgroundColor = [UIColor brownColor];
        self.text.textAlignment = NSTextAlignmentLeft;
        [self.text setFont:[UIFont systemFontOfSize:14]];
        [self addSubview:self.text];
        
        
        
    }
    return self;
}
@end
