//
//  SecondViewController.h
//  monitor
//
//  Created by xjm on 16/1/18.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalLiveController : UIViewController<UIScrollViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
{
    IBOutlet UICollectionView * colView;
    BOOL isFromStart;
}
//
@property(nonatomic, strong) IBOutlet UIScrollView  *scrollView;      //声明一个UIScrollView
@property(nonatomic, strong) IBOutlet UIPageControl *pageControl;     //声明一个UIPageControl
@property(nonatomic, strong)NSArray  *arrayImages;          //存放图片的数组
@property(nonatomic, strong)NSMutableArray *viewController; //存放UIViewController的可变数组
//
@property(nonatomic,retain) UICollectionView * colView;
@end

