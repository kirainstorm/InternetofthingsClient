//
//  LiveViewControllerCellHeader.h
//  monitor
//
//  Created by xjm on 16/1/20.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalLiveControllerCellHeader : UICollectionReusableView


@property(nonatomic,strong) UILabel * text;
@property(nonatomic,strong) UIButton * button;



@end
