//
//  LiveViewControllerCell.h
//  monitor
//
//  Created by xjm on 16/1/20.
//  Copyright © 2016年 warningsys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalLiveControllerCell : UICollectionViewCell


@property(nonatomic,strong) UIImageView *imgView;
@property(nonatomic,strong) UILabel * text;
//@property(nonatomic,strong) UILabel * textEx;


@end
